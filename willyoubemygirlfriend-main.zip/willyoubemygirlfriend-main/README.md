✨[willyoubemygirlfriend.com](https://haruto-yagami.github.io/willyoubemygirlfriend/) 

A website to confess your love! 🥰

Inspired from [elifgazioglu/doyouwannagooutwithme](https://github.com/elifgazioglu/doyouwannagooutwithme)
